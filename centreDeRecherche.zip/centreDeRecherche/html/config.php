<!-------------------- fonction connecxion avec la base de données pour les réquetes query------------------------------------>
<?php 
function connectMaBase1($req){
//conection:
$link = mysqli_connect("localhost","root",'',"centre_de_recherche") or die("Error " . mysqli_error($link));

//consultation:

$query = $req or die("Error in the consult.." . mysqli_error($link));

//execute the query.

$result = mysqli_query($link, $query);


return $result; 
}
?>
<!-------------------- fonction connexion avec la base de données pour les réquetes nonquery -------------------------------------------->
<?php
function connectMaBase2(){
@ $db = new MySQLi('localhost','root','','centre_de_recherche');

if(mysqli_connect_errno()) {
    echo 'Connection to database failed:'.mysqli_connect_error();
    exit();	
}
 return $db;
} 
?>
 
