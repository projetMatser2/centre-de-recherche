<?php
 include('config.php'); ?>

<?php
 $id=$_GET['id'];
 $page=$_GET['page'];
 $req='DELETE FROM `echantillon` WHERE id = '.$id.' ';
 $bd=connectMaBase2();
 $bd->query($req);  
 header('location:ListeEchantillon.php?page='.$page.' ');
  ?>