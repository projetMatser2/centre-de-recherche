<?php 
include("config.php");?>
<?php 
$id=$_GET['id'];
$page=$_GET['page'];
      $req=connectMaBase1("SELECT * FROM echantillon WHERE id = $id ");
      while($ET = mysqli_fetch_array($req)){
?>
<html>
    <head>
        <title>Modifier echantillon</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="../css/formulaire.css" />
         <link rel="stylesheet" href="../css/echantillon.css" /> 
    </head>
<body>
    <center>
        <div class="conteneur">
            <ul id="menu">
                <li><a href="AjouterEchantillon.php">Ajouter echantillon</a></li> 
                <li><a href="ListeEchantillon.php">Liste des echantillons</a></li>
            </ul>
				 <div id="connect"><br><br>
                     <form action="ModifierEchantillon.php" method="post">
					 <input name="id" type="hidden" value="<?php echo  $id ; ?>" />
                     <input name="page" type="hidden" value="<?php echo  $page ; ?>" />
                         <table  border="0" >
                             <tr><h1>Modifier echantillon:</h1></tr>
                             <tr>
                                 <th scope="row"><div align="left">code_Echantillon </div></th>
                                 <td><input type="text"  name="code_Echantillon" value="<?php echo $ET['code_Echantillon']; ?>" required></td>
                             </tr> 
                             <tr>
                                 <th scope="row"><div align="left"  >Filiére</div></th>
                                 <td><input type="text"   name="libelle" value="<?php echo $ET['libelle']; ?>" required> </td>
                             </tr>
                             <tr>
                                 <th scope="row"><div align="left"  >dose</div></th>
                                 <td><input type="text"   name="dose" value="<?php echo $ET['dose']; ?>" required></td>
                             </tr>
                             <tr>
                                 <th scope="row"><div align="left"  >etat</div></th>
                                 <td> <select name="etat" id="etat">
                                        <option value="valide">valide</option>
						                <option value="non valide">non valide</option>
                                      </select> 
                                </td>
                             </tr>
                             <tr>
                                 <td align="center"><a href="#" onclick="history.go( -1);" style="text-decoration:none">
                                    <input type="reset" value="Annuler"></a>  </td>
	                             <td align="center"><input type="submit" value="enregistrer" name="enregistrer" ></td></tr>
	                     <?php } ?></table>

                         <?php
                            if(isset($_POST['enregistrer'])){
                                //$id = $_POST['id'];
                                $page = $_POST['page'];
                                $id = $_POST['id'];
                                $code_Echantillon = $_POST['code_Echantillon']; 
                                $libelle = $_POST['libelle'];  
                                $dose = $_POST['dose']; 
                                $etat = $_POST['etat']; 
                                //
                                $reqA = 'UPDATE `echantillon` set  code_Echantillon= \''.$code_Echantillon.'\' , libelle= \''.$libelle.'\' , dose= \''.$dose.'\', etat= \''.$etat.'\'   WHERE  id='.$id.'  ';
                                $bd=connectMaBase2();
                                $bd->query($reqA);  
                                header('location:ListeEchantillon.php?page='.$page.' ');

                                            }?> 
                     </form>
                 </div>	
	
        </div>

    </center>
</body>
</html>