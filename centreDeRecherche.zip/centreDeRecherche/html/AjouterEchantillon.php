<?php 
//PAGE CONNEXION A LA BASE
include("config.php");?>
<?php 
echo "bonjour";
$v=" le monde";
echo $v."bonjour";
       //RECUPERER LES DONNNEES DES CHAMPS PAR NAME
      if(isset($_POST['Enregistr'])){
	    $code_Echantillon = $_POST['code_Echantillon'];
	    $libelle = $_POST['libelle'];
        $dose = $_POST['dose'];
        $etat = $_POST['etat'];
        
        // L'INSERERTION DES DONNEES DANS LA BASE DE DONNEES
            $bd=connectMaBase2();
            $sql ='INSERT INTO `echantillon` ( `code_Echantillon`, `libelle`, `dose`, `etat` ) 
            VALUES ( "'.$code_Echantillon.'", "'.$libelle.'", "'.$dose.'", "'.$etat.'" )';
                     $req=$bd->query($sql); 
	    //TEST DE VALIDATION
        if((! $sql)){
	       $bd->close();
            header("location:AjouterEchantillon.php?erreur");
        }
        else
        {
         $bd->close();
        header("location:AjouterEchantillon.php?success");
 
		} 
    }
?>  		
<html>
    <head>
        <title>Ajouter Echantillon</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="../css/formulaire.css" />
        <link rel="stylesheet" href="../css/echantillon.css" /> 
    </head>
    <body>
        <center>
        <div class="conteneur">
    		    <ul id="menu">
                    <li><a  href="#">Ajouter Echantillon</a></li> 
                    <li><a href="ListeEchantillon.php">Liste des echantillons</a></li>
                </ul>
			<div id="connect"><br><br>
                    <form action="AjouterEchantillon.php" method="post">
                        <table  border="0" >
                             <tr><h1>Ajouter echantillon :</h1></tr> 
                            <tr>
                                 <th scope="row"><div align="left"  >code_Echantillon</div></th>
                                 <td><input type="text" name="code_Echantillon" required ></td>
                            </tr> 
                            <tr>
                                 <th scope="row"><div align="left"  >libelle</div></th>
                                 <td><input type="text" name="libelle" required ></td>
                            </tr> 
                            <tr>
                                 <th scope="row"><div align="left"  >dose</div></th>
                                 <td><input type="text" name="dose" required ></td>
                            </tr> 
                            <tr>
                                 <th scope="row"><div align="left"  >etat</div></th>
                                 <td> <select name="etat" id="etat">
                                        <option value="valide">valide</option>
						                <option value="non valide">non valide</option>
                                      </select> 
                                </td>
                            </tr> 
                            <tr>
                                 <td align="center"> <input type="reset" value="Annuler"> </td>
	                             <td align="center"><input type="submit" value="Ajouter" name="Enregistr">
                                    <?php if(isset($_GET['erreur'])){
                        			echo '<span class="ok">Echec dajout</span>';} 
                        			if(isset($_GET['success'])){
                        			echo ' Ajout reussi';} ?>
                        		 </td>
                            </tr>
                        </table>                           
                    </form>				 
            </div>	
        </div>
        </center>
    </body>
</html>