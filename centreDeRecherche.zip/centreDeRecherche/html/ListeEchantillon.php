<?php include("config.php");

$terme = "";
if (isset($_GET['terme'])){
$terme = $_GET['terme'];
                                
        }
?>
<html>
  <head>
    <title>Echantillon</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../css/formulaire.css" />
    <link rel="stylesheet" href="../css/tableau.css" />
    <link rel="stylesheet" href="../css/echantillon.css" /> 
  </head>
  <body>
    <center>
    <div class="conteneur">
  	  <ul id="menu">
    	  <li><a  href="AjouterEchantillon.php">Ajouter Echantillon</a></li> 
        <li><a href="#">Liste des echantillons</a></li>
      </ul>
	    <div id="connect"><br> 

          <form method="GET" action="">
              Chercher une Echantillon par code:  
              <input type="text" name="terme"	 placeholder="search echant"  value="<?php if(isset($_GET['terme'])){echo $_GET['terme'];}?>"/>
              <input  type="submit" value = "Rechercher" />
          </form>
          <h1>Liste des echantillons</h1> 
          <table border="1" align="center">
				      <tr ><th>id</th><th>code_Echantillon</th><th>libelle</th><th>dose</th><th>etat</th><th>Modifier</th><th>Supprimer</th></tr>
				        <?php 
                   $messagesParPage=5;
                   
                      $reqC = connectMaBase1('SELECT count(*) AS total  FROM `echantillon` WHERE code_Echantillon LIKE \'%'.$terme.'%\' '); 
                       while($don1=mysqli_fetch_array($reqC)){
                            $total=$don1['total'];
                            $nombreDePages=ceil($total/$messagesParPage);
                            if(isset($_GET['page']) ){
                                $pageActuelle=intval($_GET['page']);
                                //$terme=$_GET['terme'];
                                //if(isset($_GET['terme'])){echo "&terme=".$_GET['terme'];}
                                if($pageActuelle > $nombreDePages){
                                  $pageActuelle=$nombreDePages;
                                  
                                }
                            }

                            else{
                              $pageActuelle=1; 
                            }
                            $premiereEntree=($pageActuelle-1)*$messagesParPage; // On calcul la première entrée à lire
                              // La requête sql pour récupérer les messages de la page actuelle.
                               
                            $retour_messages=connectMaBase1('SELECT * FROM echantillon WHERE code_Echantillon LIKE \'%'.$terme.'%\' 
                            ORDER BY id DESC LIMIT '.$premiereEntree.', '.$messagesParPage.'');
                            while($donnees_messages=mysqli_fetch_array($retour_messages)) // On lit les entrées une à une grâce à une boucle                          
                                              {?>

				      <tr>	
        				 <td><?php echo $donnees_messages['id'];?></td>
        				 <td><?php echo $donnees_messages['code_Echantillon'];?></td>
        				 <td><?php echo $donnees_messages['libelle'];?> </td> 
        				 <td><?php echo $donnees_messages['dose'];?> </td> 
                 <td><?php echo $donnees_messages['etat'];?> </td> 
        				 <td><a href="ModifierEchantillon.php?id=<?php echo $donnees_messages['id'];?>&amp;page=<?php echo $pageActuelle;?> "><img src="../image/edit.PNG" width="25"></a></td> 
                 <td><a href="SupprimerEchantillon.php?id=<?php echo $donnees_messages['id'];?>&amp;page=<?php echo $pageActuelle;?> ">
                             <img src="../image/supp.PNG" width="25px"height="25px" onclick="return(confirm('Voulez-vous supprimer cet echantillon?'));"></a></td>
              </tr>
				     <?php } }?>
				  </table>

          <!-- LA PAGINATION -->
				  <p align="center">Page :
              <?php
             
               
                for($i=1; $i<=$nombreDePages; $i++) //On fait notre boucle
                {
                  //On va faire notre condition
                    if($i==$pageActuelle) //Si il s'agit de la page actuelle...
                    {
                        echo ' [ '.$i.' ] '; 
                    }	
                    else //Sinon...
               {
                    echo ' <a href="ListeEchantillon.php?page='.$i.'&amp;terme='.$terme.' ">'.$i.'</a> ';
               }
          }
          echo '</p>'; ?>		
        </div>	
      </div>
    </center>
  </body>
</html>